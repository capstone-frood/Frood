package com.frood.app.domain.model

data class Information(
    val id: Long,
    val imageRes: Int
)
